#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define MAX_LEN 8
int length;
int length1;
int length2;

int* init_arr;

void merge(int arr[], int left, int mid, int right){
    int i, j, k;
    int llen = mid - left + 1;
    int rlen = right - mid;

    int larr[llen], rarr[rlen];

    for(i = 0; i < llen; i++){
        larr[i] = arr[left + i];
    }
    for(j = 0; j < rlen; j++){
        rarr[j] = arr[mid + 1 + j];
    }

    i = 0; j = 0; k = left;

    while(i < llen && j < rlen){
        if(larr[i] <= rarr[j]){
            arr[k] = larr[i];
            i++;
        }
        else{
            arr[k] = rarr[j];
            j++;
        }
        k++;
    }

    while(i < llen){
        arr[k] = larr[i];
        i++;
        k++;
    }

    while(j < rlen){
        arr[k] = rarr[j];
        j++;
        k++;
    }
}
void merge_sort(int arr[], int left, int right){
    if(left < right){
        int mid = left + (right - left) / 2;

        merge_sort(arr, left, mid);
        merge_sort(arr, mid + 1, right);
        merge(arr, left, mid, right);
    }
}

void* merge_sort_p(void* arg){
    int tid = (long)arg;
    if(tid == 0){
        //printf("left");
        merge_sort(init_arr, 0, length1 - 1);
    }
    else{
        //printf("right");
        merge_sort(init_arr, length1 , length - 1);
    }
    return NULL;
}


void psort(FILE* arrFile){
    //  read array from text file
    int i;
    int num_count = 0;
    int num;
    int arr_size = 8;
    init_arr = malloc(arr_size * sizeof(int));
    int* a = init_arr;
    while(fscanf(arrFile, "%d", &num) != EOF){
        num_count++;
        *a++ = num;
        // dynamically expand array
        if(num_count == arr_size){
            arr_size *= 2;
            int* new_arr = malloc(arr_size * sizeof(int));
            for(int i = 0; i < num_count; i++){
                new_arr[i] = init_arr[i];
            }
            free(init_arr);
            init_arr = new_arr;
            a = init_arr + num_count;
        }
    }
    // for(int i = 0; i < num_count; i++){
    //     printf("%d ", init_arr[i]);
    // }
    // printf("\n");

    a -= num_count;
    length = num_count;
    length1 = num_count / 2;
    length2 = num_count - length1;

    /*
        thread

    */
    pthread_t pthread[2];

    //  create thread
    for(long i = 0; i < 2; i++){

        pthread_create(&pthread[i], NULL, &merge_sort_p, (void*)i);
    }
    //  join thread
    for(i = 0; i < 2; i++){
        pthread_join(pthread[i], NULL);
    }
    // for(int i = 0; i < num_count; i++){
    //     printf("%d ", init_arr[i]);
    // }
    // printf("\n");

    merge(init_arr, 0, (length - 1)/2, length - 1);

    for(int i = 0; i < num_count; i++){
        printf("%d ", init_arr[i]);
    }
    printf("\n");
    free(init_arr);
}



int main(int argc, char* argv[])
{

    FILE* arrFile;
    if(argc <= 1){
        arrFile = stdin;
    }else{
        arrFile = fopen(argv[1], "r");
    }
    psort(arrFile);

    
}
