#include "types.h"
#include "stat.h"
#include "user.h"



char buf[512];


void uniq(int fd) {
    int wordMAX = 512;
    int words = 0;
    char* lines = malloc(sizeof(char) * wordMAX);
    int num_lines;
    int i, n;
    
    while((n = read(fd, buf, sizeof(buf))) > 0){
        for(i = 0; i < n; i++){

            if(words >= wordMAX){
                char* new_lines = malloc(2 * wordMAX * sizeof(char));
                memmove(new_lines, lines, wordMAX);
                wordMAX *= 2;
                free(lines);
                lines = new_lines;
            }

            lines[words] = buf[i];

            words++;

            if(buf[i] == '\n'){
                num_lines++;
            }
        }
    }

    if (n < 0) {
        printf(1, "uniq: read error\n");
        exit();
    }


    char* oldline = malloc(sizeof(char) * words); 
    char* newline = malloc(sizeof(char) * words);
    int old_full;
    old_full = 0;
    int j = 0;

    for(i = 0; i < words; i++){
        if(old_full == 0){
            oldline[i] = lines[i];
            if(lines[i] == '\n'){
                printf(1, "%s", oldline);
                old_full = 1;
            }
        }
        else{
            newline[j] = lines[i];
            j++;
            if(lines[i] == '\n'){
                if(strcmp(oldline, newline) != 0){
                    printf(1, "%s", newline);
                }
                free(oldline);
                oldline = malloc(sizeof(char) * words);
                oldline = newline;
                newline = malloc(sizeof(char) * words);
                j = 0;
            }
        }
    }
    newline[j] = '\n';
    if(strcmp(oldline, newline) != 0){
        printf(1, "%s", newline);
    }

    free(oldline);
    free(newline);
    free(lines);
    exit();
}

int main(int argc, char* argv[]){

    int fd, i;

    if(argc <= 1){
        uniq(0);
        exit();
    }

    for (i = 1; i < argc; i++) {
        if ((fd = open(argv[i], 0)) < 0) {
            printf(1, "uniq: cannot open %s\n", argv[i]);
            exit();
        }
        uniq(fd);
        close(fd);
    }

    exit();
}