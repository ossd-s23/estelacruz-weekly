#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"


//Fibonacci sequence
int fib(int n){
    if (n <= 1) {
        return 1;
    }
    return fib(n-1) + fib(n-2);
}
//Use this for long computation
//fib(35) takes roughly 30 secs
void longComputation(){
    fib(35);
}


int
main(int argc, char *argv[])
{
        //Fill this in
    int pids[20];
    int i;
    int n = 20;


    for (i = 0; i < n; ++i) {
        if ((pids[i] = fork()) == 0) {
            longComputation();
            exit();
        }
    }

    int pid;
    int ctime, ttime, retime, rutime, stime;
    int avg_w, avg_r, avg_s, avg_turn;
    while (n > 0) {
        pid = waitstat(&ctime, &ttime, &retime, &rutime, &stime);
        printf(1, "PID[%d] Creation[%d] Termination[%d] Ready Time[%d] Running Time[%d] Sleep Time[%d]\n",
            pid, ctime, ttime, retime, rutime, stime);
        --n;
        avg_w += retime;
        avg_r += rutime;
        avg_s += stime;
        avg_turn += (ttime - ctime);
        
    }
    printf(1, "Average Wait Time[%d] Average Running Time[%d] Average Sleep Time[%d] Average Turnaround Time[%d]\n",
        avg_w/20, avg_r/20, avg_s/20, avg_turn/20);

    exit();
}