#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

char buf[512];

void tail(int fd, int num, int flag){
    int wordMAX = 512;
    int words = 0;
    char* lines = malloc(sizeof(char) * wordMAX);
    int num_lines = 0;
    int i, n;


    // create dynamic array
    while((n = read(fd, buf, sizeof(buf))) > 0){
        for(i = 0; i < n; i++){

            if(words >= wordMAX){
                char* new_lines = malloc(2 * wordMAX * sizeof(char));
                memmove(new_lines, lines, wordMAX);
                wordMAX *= 2;
                free(lines);
                lines = new_lines;
            }
            lines[words] = buf[i];
            words++;
            if(buf[i] == '\n'){
                num_lines++;
            }
        }
    }

    if (n < 0) {
        printf(1, "tail: read error\n");
        exit();
    }

    if(num == -1){
        if(flag == 0) num = num_lines;
        else num = words;
    }
    // flag 3, 4 inverse the index
    if(flag > 1){
        if(flag == 2) num = (num_lines - num + 2);
        else num = (words - num + 1);
        flag -= 2;
        // check if num is valid
        if(num < 0){
            printf(1, "tail: cannot start from line %d", num);
            exit();
        }
    }
    // printf(1, "%d %d %d %d\n", num_lines, words, num, flag);
    // do tail job
    switch(flag){
        case 0:             // count by line
            while(num_lines >= num){
                // remove head line
                if(*lines++ == '\n'){
                    num_lines--;
                }
            }
            break;
        case 1:             // count by bytes
            while(words-- > num){
                lines++;
            }

    }
    printf(1, "%s\n", lines);
    free(lines);

}




int main(int argc, char *argv[]) {
    int fd;
    int toggle = 0;
    if (argc <= 1) {
        tail(0, 10, toggle);
        exit();
    }
    else{
        if ((fd = open(argv[argc-1], 0)) < 0) {
            printf(1, "tail: cannot open %s\n", argv[argc -1]);
            exit();
        }
        // with and without flag
        if(argc < 3){   //without flag
            tail(fd, 10, toggle);
        }   
        else{           //with flag
            if(strcmp(argv[1], "-c") == 0){
                toggle++;
            }
            if(*argv[2] == '+'){
                toggle+=2;
                argv[2]++;
            }

            if(argc == 3){
                tail(fd, -1, toggle);
            }
            else{
                // printf(1, "%d %d\n", atoi(argv[2]), toggle);
                tail(fd, atoi(argv[2]), toggle);
            }
        }
        close(fd);
        
    }
    exit();
}
