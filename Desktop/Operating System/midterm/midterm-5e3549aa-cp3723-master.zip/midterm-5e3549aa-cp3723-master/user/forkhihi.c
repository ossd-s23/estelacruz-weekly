#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"






int main(int argc, char *argv[]) {

    for(int i = 0; i < 4; i++){
        if(fork() == 0){
            printf(1, "child\n");
            exit();
        }
        else{
            printf(1, "parent\n");
            wait();
            exit();
        }
    }
    exit();
}
